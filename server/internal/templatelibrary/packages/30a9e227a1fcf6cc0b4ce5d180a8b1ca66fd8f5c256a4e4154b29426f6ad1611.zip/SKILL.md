---
name: storyboard-to-timed-video-prompt
description: Convert all Storyboard A plain-text shots produced by script-to-storyboard-a into one Chinese video-generation prompt under 1200 Chinese characters. Output only a compact reference-rule block, story-position line, one contiguous timed sequence covering every shot, three concise global constraints, and one visual-style line. Use for 分镜A转视频提示词、全部分镜合成一段视频提示词、连续时间轴视频提示词、一键商业片 or 漫剧视频生成. Never process only the first shot, never create separate prompts per shot, and never output JSON or tables.
---

# Storyboard To Timed Video Prompt

Read every Storyboard A block from `$script-to-storyboard-a` and combine all shots into one compact, continuous plain-text video prompt. The final response must be no more than 1200 Chinese characters including labels, punctuation, spaces, and line breaks. Count and shorten internally before answering; do not print the count.

## Process

1. Read and count all input shots before drafting. Accept only the eight Skill 1 fields: `镜号、时长、画面描述、景别、光影氛围、对白·旁白、音效、运镜`.
2. Extract only continuity-critical characters, scenes, and props while drafting the timed sequence. Do not create `出场角色` or `背景场景` sections.
3. Copy every supplied dialogue or narration verbatim into the relevant timed segment. Preserve all source actions, sound cues, transitions, and the ending.
4. Start at `0秒`, preserve source order, and make the next segment start exactly at the previous segment's end. Each input shot must appear at least once in the timeline; do not reset time at scene changes.
5. Use the compact segment format below. Keep each segment concise: one visible action sentence, short prohibitions, short continuity constraints, one position/orientation phrase, one camera phrase, one audio phrase, and a 4-10 character summary.
6. End with exactly three global output constraints and one visual-style line. If the source supplies a style, preserve its core; otherwise infer one concise style from genre and tone without adding plot facts.

## Segment format

Use one block for each input shot, in order:

0-3秒：
画面：……
禁止：……
约束：……
站位与朝向：……
运镜：……
音效：……
（简述：……）

For `音效`, include exact dialogue/narration after the sound cue when present: `键盘声；旁白：“……”`. Write `无` only when the source has no audible cue. Never add a separate dialogue field.

## Compact reference rules

Include this section exactly once before the story-position line:

参考图使用规则：
角色图只参考角色形象，不参考姿势、表情、角度、构图；场景图只参考空间结构，不复制站位与光影；道具图只参考形状、大小、结构，正反面和多视图物体遵守客观逻辑。

## Mandatory output order

参考图使用规则：
……

当前分镜序列为故事位置

---

0-3秒：……
（继续输出全部时间段）

---

输出约束：
1. 角色、服装、场景、道具、光线和动作前后连续。
2. 禁止新增人物、物体、文字、剧情，禁止变形、穿模、镜像、跳变。
3. 全部时间段从0秒连续覆盖所有输入分镜，提示词总长度不超过1200字。

[视觉风格：……]

## Absolute restrictions

- Do not output `出场角色` or `背景场景` sections.
- Do not use JSON, YAML, XML, CSV, Markdown tables, code fences, shot-count reports, total-duration reports, explanations, summaries, or validation notes.
- Do not create separate outputs named `提示词1`, `提示词2`, or one prompt per shot.
- Do not stop after the first shot or use `后续同理`、`其余省略`、`同上`.
- Do not reset timestamps to zero at scene changes. Maintain one continuous timeline across all supplied shots.
- Do not omit dialogue, narration, sound, props, transitions, or the final shot.
- Keep the final response at or below 1200 Chinese characters. Shorten repeated adjectives and clauses before dropping any source shot, action, dialogue, sound cue, or ending.

## Silent quality check

Verify internally that every input shot is represented once in chronological order, the timeline starts at zero and is contiguous, all required timed fields are present, original dialogue/narration is verbatim, the three global constraints appear once, and the complete response is <=1200 Chinese characters.

Do not print this check or its result.