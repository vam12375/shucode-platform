#!/usr/bin/env python3
"""餐饮视频提示词预检（仅标准库）。

用法：
  lint_prompt.py FILE --duration 30                           # 模型取档案的 default
  lint_prompt.py FILE --duration 30 --model seedance-2.5      # .md 检查其中每个含【时间轴】的代码块
  lint_prompt.py FILE --duration 15,15 --model seedance-2.0   # 多段时长不同用逗号
  lint_prompt.py FILE --duration 15,15 --model seedance-2.0 --json
  lint_prompt.py --scan-text FILE                             # 只扫极限词与提醒词（字卡、旁白、发布文案）

--model 读 restaurant-video-director/references/model-profiles.json：
  单段时长超过模型上限、参考图超过模型上限 → 错误；时间段数超过 max_ranges → 警告。
退出码：0 无错误；1 有错误；2 用法或读文件失败。
区块名、时间范围写法、对白写法见 seedance-prompt-composer/references/prompt-skeleton.md。
极限词来自 ../references/banned-words.md 里的 banned / caution 围栏块。
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

REQUIRED_BLOCKS = ["规格", "素材分工", "连续性", "时间轴", "声音", "禁止"]
SOFT_CHARS = 2000  # 平台上限未确认：超过软上限只警告
HARD_CHARS = 3000
MAX_RANGES = 6  # 没有模型档案时的默认值
MIN_RANGE_SECONDS = 2
MAX_DIALOGUE_LINES = 3
MAX_DIALOGUE_CHARS = 12
DEFAULT_REF_PREFIX = "@图片"
HERE = Path(__file__).resolve().parent
BANNED_FILE = HERE.parent / "references" / "banned-words.md"
PROFILES_FILE = HERE.parents[1] / "restaurant-video-director" / "references" / "model-profiles.json"

BLOCK_RE = re.compile(r"^【([^】\n]+)】", re.M)
RANGE_RE = re.compile(r"^[ \t]*(\d+)[ \t]*[–—\-~][ \t]*(\d+)[ \t]*秒", re.M)
DIALOGUE_RE = re.compile(r"^[ \t]*(\d+)[ \t]*秒[ \t]*(.+?)[：:][ \t]*[“\"「](.+?)[”\"」][ \t]*$", re.M)
FENCE_RE = re.compile(r"^```[^\n]*\n(.*?)^```", re.M | re.S)


class Report:
    def __init__(self) -> None:
        self.errors: list[dict] = []
        self.warnings: list[dict] = []

    def err(self, where: str, msg: str) -> None:
        self.errors.append({"where": where, "msg": msg})

    def warn(self, where: str, msg: str) -> None:
        self.warnings.append({"where": where, "msg": msg})

    def result(self, chars: int) -> dict:
        return {"chars": chars, "errors": self.errors, "warnings": self.warnings}


def load_word_lists(path: Path = BANNED_FILE):
    banned: list[re.Pattern] = []
    caution: list[re.Pattern] = []
    if not path.exists():
        return banned, caution, f"找不到 {path}，已跳过极限词检查"
    text = path.read_text(encoding="utf-8")
    for m in re.finditer(r"^```(banned|caution)[ \t]*\n(.*?)^```", text, re.M | re.S):
        target = banned if m.group(1) == "banned" else caution
        for line in m.group(2).splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                target.append(re.compile(line))
    return banned, caution, None


def load_profiles(path: Path = PROFILES_FILE):
    """返回 (档案 dict 或 None, 提示信息或 None)。"""
    if not path.exists():
        return None, f"找不到 {path}，已跳过模型限制检查"
    try:
        return json.loads(path.read_text(encoding="utf-8")), None
    except (OSError, ValueError) as exc:
        return None, f"读取模型档案失败：{exc}"


def ref_regexes(prefix: str):
    p = re.escape(prefix)
    return re.compile(rf"^[ \t]*{p}(\d+)[ \t]*[：:]", re.M), re.compile(rf"{p}(\d+)")


def _snippet(text: str, m: re.Match, pad: int = 8) -> str:
    a, b = max(0, m.start() - pad), min(len(text), m.end() + pad)
    return text[a:b].replace("\n", " ")


def scan_words(text: str, where: str, rep: Report, banned, caution) -> None:
    for rx in banned:
        for m in rx.finditer(text):
            rep.err(where, f"极限或违规用语“{m.group(0)}”：…{_snippet(text, m)}…")
    for rx in caution:
        for m in rx.finditer(text):
            rep.warn(where, f"需要依据或限定条件的用语“{m.group(0)}”：…{_snippet(text, m)}…")


def split_blocks(text: str) -> tuple[dict[str, str], list[str]]:
    """{区块名: 正文}，正文到下一个行首【…】为止；同名区块记入 dups。"""
    matches = list(BLOCK_RE.finditer(text))
    blocks: dict[str, str] = {}
    dups: list[str] = []
    for i, m in enumerate(matches):
        end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        if m.group(1) in blocks:
            dups.append(m.group(1))
        blocks[m.group(1)] = text[m.end():end]
    return blocks, dups


def check_timeline(tl: str, duration: int, rep: Report, max_ranges: int = MAX_RANGES) -> None:
    matches = list(RANGE_RE.finditer(tl))
    if not matches:
        rep.err("时间轴", "没有 `0–4秒` 形式的时间段")
        return
    ranges = [(int(m.group(1)), int(m.group(2))) for m in matches]
    if ranges[0][0] != 0:
        rep.err("时间轴", f"第 1 段从 {ranges[0][0]} 秒开始，应从 0 开始")
    for i, (a, b) in enumerate(ranges, 1):
        if b <= a:
            rep.err("时间轴", f"第 {i} 段 {a}–{b} 秒：终点必须大于起点")
        elif b - a < MIN_RANGE_SECONDS:
            rep.warn("时间轴", f"第 {i} 段 {a}–{b} 秒短于 {MIN_RANGE_SECONDS} 秒")
        if i > 1 and a != ranges[i - 2][1]:
            rep.err("时间轴", f"第 {i} 段起点 {a} 与上一段终点 {ranges[i - 2][1]} 不连续")
    if ranges[-1][1] != duration:
        rep.err("时间轴", f"最后一段结束于 {ranges[-1][1]} 秒，应为 {duration} 秒")
    if len(ranges) > max_ranges:
        rep.warn("时间轴", f"{len(ranges)} 个时间段，超过建议的 {max_ranges} 个")
    for i, m in enumerate(matches, 1):
        end = matches[i].start() if i < len(matches) else len(tl)
        chunk = tl[m.start():end]
        if "镜头：" not in chunk and "镜头:" not in chunk:
            rep.warn("时间轴", f"第 {i} 段缺少“镜头：”")
        if "结束画面" not in chunk:
            rep.warn("时间轴", f"第 {i} 段缺少“结束画面：”")


def check_refs(blocks: dict[str, str], rep: Report, prefix: str = DEFAULT_REF_PREFIX,
               image_limit: int | None = None, model_name: str = "") -> None:
    decl_re, use_re = ref_regexes(prefix)
    mat = blocks.get("素材分工", "")
    declared = [int(x) for x in decl_re.findall(mat)]
    if not declared:
        rep.err("素材分工", f"没有 `{prefix}N：` 形式的声明")
        return
    uniq = sorted(set(declared))
    if len(uniq) != len(declared):
        rep.err("素材分工", f"{prefix}编号重复声明")
    if uniq != list(range(1, len(uniq) + 1)):
        rep.warn("素材分工", f"{prefix}编号不是从 1 起连续的：{uniq}")
    if image_limit is not None and len(uniq) > image_limit:
        rep.err("素材分工", f"声明了 {len(uniq)} 张参考图，超过{model_name or '该模型'}的上限 {image_limit}")
    for line in mat.splitlines():
        m = decl_re.match(line)
        if m and "不取" not in line:
            rep.warn("素材分工", f"{prefix}{m.group(1)} 没写“不取……”")
    outside = "\n".join(body for name, body in blocks.items() if name != "素材分工")
    used = {int(x) for x in use_re.findall(outside)}
    for n in sorted(used - set(declared)):
        rep.err("素材分工", f"{prefix}{n} 被引用但没有声明")
    for n in sorted(set(declared) - used):
        rep.warn("素材分工", f"{prefix}{n} 已声明但没有被使用")


def check_sound(blocks: dict[str, str], duration: int, sfx_only: bool, rep: Report, banned, caution) -> None:
    snd = blocks.get("声音", "")
    if "对白" not in snd:
        rep.warn("声音", "没有写对白；无对白请写“对白：无（……）”")
    lines = DIALOGUE_RE.findall(snd)
    if len(lines) > MAX_DIALOGUE_LINES:
        rep.warn("声音", f"对白 {len(lines)} 句，超过 {MAX_DIALOGUE_LINES} 句")
    for t, _who, line in lines:
        if int(t) > duration:
            rep.err("声音", f"对白时间 {t} 秒超过时长 {duration} 秒")
        if len(line) > MAX_DIALOGUE_CHARS:
            rep.warn("声音", f"{t} 秒对白 {len(line)} 字，建议 ≤8 字（上限 {MAX_DIALOGUE_CHARS}）")
        scan_words(line, f"对白@{t}秒", rep, banned, caution)
    if sfx_only and not re.search(r"BGM[：:]\s*无", snd):
        rep.err("声音", "多段拼接应为 sfx_only：请写“BGM：无（后期统一配乐）”")


def lint_prompt(text: str, duration: int, continuation: bool, sfx_only: bool,
                soft: int, hard: int, banned, caution, profile: dict | None = None) -> dict:
    rep = Report()
    text = text.strip()
    blocks, dups = split_blocks(text)
    for name in dups:
        rep.warn("区块", f"【{name}】出现多次，只检查最后一个")

    prof = profile or {}
    model_name = prof.get("name", "")
    prefix = (prof.get("ref_tag") or {}).get("image", DEFAULT_REF_PREFIX)
    image_limit = (prof.get("refs") or {}).get("image")
    max_ranges = prof.get("max_ranges", MAX_RANGES)

    n = len(text)
    if n > hard:
        rep.err("长度", f"{n} 字，超过硬上限 {hard}")
    elif n > soft:
        rep.warn("长度", f"{n} 字，超过建议上限 {soft}；按骨架里的删减顺序精简")

    for name in REQUIRED_BLOCKS:
        if name not in blocks:
            rep.err("区块", f"缺少【{name}】")
    if continuation and "承接" not in blocks:
        rep.err("区块", "第 2 段起必须有【承接】")
    if not continuation and "承接" in blocks:
        rep.warn("区块", "首段不应有【承接】")

    spec = blocks.get("规格", "")
    if "9:16" not in spec:
        rep.err("规格", "未声明竖屏 9:16")
    if f"{duration}秒" not in spec:
        rep.err("规格", f"未声明时长 {duration}秒")
    mx, mn = prof.get("single_pass_max"), prof.get("single_pass_min")
    if mx and duration > mx:
        rep.err("规格", f"单段 {duration} 秒超过{model_name}的单段上限 {mx} 秒：请按幕拆段（plan_segments.py）")
    elif mn and duration < mn:
        rep.warn("规格", f"单段 {duration} 秒短于{model_name}的下限 {mn} 秒")

    if "时间轴" in blocks:
        check_timeline(blocks["时间轴"], duration, rep, max_ranges)
    if "素材分工" in blocks:
        check_refs(blocks, rep, prefix, image_limit, model_name)
    if "声音" in blocks:
        check_sound(blocks, duration, sfx_only, rep, banned, caution)

    if "禁止" in blocks and "文字" not in blocks["禁止"]:
        rep.warn("禁止", "没有禁止“画面出现可读文字”")
    if "不增减" not in text:
        rep.warn("保真", "没有菜品保真句（“不增减食材，不改变摆盘与器皿”）")
    return rep.result(n)


def extract_prompts(path: Path | None, stdin_text: str | None = None) -> list[str]:
    text = stdin_text if stdin_text is not None else path.read_text(encoding="utf-8")
    if path is not None and path.suffix.lower() == ".md":
        return [m.group(1) for m in FENCE_RE.finditer(text) if "【时间轴】" in m.group(1)]
    return [text]


def print_result(label: str, res: dict) -> None:
    status = "FAIL" if res["errors"] else "OK"
    print(f"== {label}  [{status}]  {res['chars']} 字  错误 {len(res['errors'])}  警告 {len(res['warnings'])}")
    for e in res["errors"]:
        print(f"  ERROR  {e['where']}: {e['msg']}")
    for w in res["warnings"]:
        print(f"  WARN   {w['where']}: {w['msg']}")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="餐饮视频提示词预检", epilog=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("file", nargs="?", help="提示词文件（.txt 单段；.md 检查其中每个含【时间轴】的代码块；- 读标准输入）")
    ap.add_argument("--duration", help="每段时长（秒）；多段时长不同用逗号，如 15,15")
    ap.add_argument("--model", help="模型档案的 key（决定单段上限、参考图上限、时间段数）；省略时用档案的 default")
    ap.add_argument("--profiles", type=Path, default=PROFILES_FILE, help="模型档案路径")
    ap.add_argument("--continuation", action="store_true", help="单段文件是第 2 段起（要求有【承接】）")
    ap.add_argument("--sound-mode", choices=["auto", "full", "sfx_only"], default="auto",
                    help="auto：多段按 sfx_only，单段按 full")
    ap.add_argument("--soft-chars", type=int, default=SOFT_CHARS)
    ap.add_argument("--hard-chars", type=int, default=HARD_CHARS)
    ap.add_argument("--scan-text", metavar="FILE", help="只扫描一个文本文件里的极限词与提醒词")
    ap.add_argument("--json", action="store_true", help="输出 JSON")
    args = ap.parse_args(argv)

    banned, caution, note = load_word_lists()
    if note:
        print(f"注意：{note}", file=sys.stderr)

    results: list[dict] = []
    model_key: str | None = None
    try:
        if args.scan_text:
            text = Path(args.scan_text).read_text(encoding="utf-8")
            rep = Report()
            scan_words(text, "文案", rep, banned, caution)
            results.append({"label": args.scan_text, **rep.result(len(text))})
        else:
            if not args.file or not args.duration:
                ap.error("需要 FILE 和 --duration（或使用 --scan-text）")
            data, pnote = load_profiles(args.profiles)
            if pnote:
                print(f"注意：{pnote}", file=sys.stderr)
            profile = None
            if data:
                model_key = args.model or data.get("default")
                profile = (data.get("models") or {}).get(model_key)
                if profile is None:
                    print(f"模型档案里没有 {model_key!r}，可选：{', '.join(data.get('models') or {})}", file=sys.stderr)
                    return 2
            elif args.model:
                print("指定了 --model，但没有可用的模型档案", file=sys.stderr)
                return 2
            if args.file == "-":
                path, prompts = None, extract_prompts(None, sys.stdin.read())
            else:
                path = Path(args.file)
                prompts = extract_prompts(path)
            if not prompts:
                print("没有找到含【时间轴】的提示词代码块", file=sys.stderr)
                return 2
            try:
                durations = [int(x) for x in args.duration.split(",")]
            except ValueError:
                ap.error("--duration 必须是整数或逗号分隔的整数")
            if len(durations) == 1:
                durations *= len(prompts)
            if len(durations) != len(prompts):
                ap.error(f"找到 {len(prompts)} 段提示词，但 --duration 给了 {len(durations)} 个值")
            multi = len(prompts) > 1
            sfx_only = {"sfx_only": True, "full": False}.get(args.sound_mode, multi)
            for i, (p, d) in enumerate(zip(prompts, durations)):
                continuation = args.continuation or i > 0
                res = lint_prompt(p, d, continuation, sfx_only, args.soft_chars, args.hard_chars,
                                  banned, caution, profile)
                tag = f"，{model_key}" if model_key else ""
                label = f"{args.file} 段 {i + 1}/{len(prompts)}（{d} 秒{tag}）" if multi else f"{args.file}（{d} 秒{tag}）"
                results.append({"label": label, **res})
    except OSError as exc:
        print(f"读取失败：{exc}", file=sys.stderr)
        return 2

    failed = any(r["errors"] for r in results)
    if args.json:
        print(json.dumps({"pass": not failed, "model": model_key, "results": results}, ensure_ascii=False, indent=2))
    else:
        for r in results:
            print_result(r["label"], r)
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
