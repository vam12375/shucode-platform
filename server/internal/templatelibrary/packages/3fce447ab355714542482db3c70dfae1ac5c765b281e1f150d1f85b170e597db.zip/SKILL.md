---
name: food-video-qa
description: 餐饮视频生成前的预检：用脚本检查提示词结构（时间轴连续、@图片分工、字数、对白数量、极限词），并按所选模型检查单段时长上限、参考图数量上限和时间段数；再按清单检查菜品真实度、广告合规、人像授权、AI 标识和多段接缝，输出可执行的修改建议。在 seedance-prompt-composer 写完提示词、真正生成视频（花积分）之前使用；也可用来扫描优惠文案、字卡和发布文案里的违规用语。
---

# 预检（生成前把关）

生成一次 15–30 秒视频成本不低，多段更是成倍，先把能拦的拦住。

## 1. 脚本检查（确定性）

```bash
python3 scripts/lint_prompt.py <提示词.txt 或 示例.md> --duration 30 --model seedance-2.5
python3 scripts/lint_prompt.py <文件.md> --duration 15,15 --model seedance-2.0   # 多段：每段一个时长
python3 scripts/lint_prompt.py <文件> --duration 30 --json                         # 供程序调用
python3 scripts/lint_prompt.py --scan-text <文案.txt>                               # 扫字卡、旁白、发布文案
```

- `--model` 读 `../restaurant-video-director/references/model-profiles.json`；省略时用档案的 default。
- `--duration` 是**每段**的时长，不是整片时长。
- `.md` 文件检查其中每个含【时间轴】的代码块；第 2 段起自动要求【承接】，多段自动按 `sfx_only` 检查。
- 单段 `.txt` 是第 2 段起时加 `--continuation`。

检查项：区块齐全（规格 / 素材分工 / 连续性 / 时间轴 / 声音 / 禁止）· 时间轴从 0 起连续、末端 = 该段时长、每段 ≥2s、时间段数 ≤ 档案的 `max_ranges`、每段有"镜头"和"结束画面" · **单段时长 ≤ 档案的 `single_pass_max`** · @图片声明与使用一致、每个声明带"不取"、**数量 ≤ 档案的 `refs.image`** · 规格含 9:16 与时长 · 对白 ≤3 句且每句 ≤12 字 · 对白里的极限词 · 禁止区块含"文字" · 菜品保真句（不增减）· 字数软 / 硬上限。

## 2. 人工清单（逐条判断）

| 类别 | 检查 | 不通过时 |
|---|---|---|
| 菜品真实 | 每个菜品 @图片有外观锁定句；没有"更大 / 更丰盛 / 满满"；菜品镜头 ≤3s；cold / iced 没有热气 | 改写素材行与菜品 beat |
| 不编造 | 画面里没有菜单上没有的菜；价格与优惠来自 brief | 删除或改回商家原文 |
| 文案合规 | 旁白、字卡、发布文案过 `--scan-text`；"限时 / 免费 / 0 元"带条件 | 用 `references/banned-words.md` 的替换建议 |
| 人像 | 人物图有授权才用；无明星或公众人物；无儿童近景 | 降级为 pov / foodie_ai |
| 模型与人脸 | 外接缝 ≥2 时出镜方式已降级（foodie_ai / owner → pov）；档案 `face_reference = blocked_reported` 时没有用真人照片做参考 | 按 `../restaurant-story-planner/references/hosts.md` 降级 |
| 他店元素 | 无他店招牌与品牌 logo；无可读文字 | 加虚化或删除 |
| AI 标识 | `post.ai_label = true` | 补上 |
| 后厨卫生 | 有后厨镜头时：干净、厨师戴帽 | 补充描述 |
| 接缝 | 每个外接缝有类型，出口写进上一段的结束画面，入口写进下一段的【承接】；段尾是静态或半静态构图；冷菜没有用 `steam_wipe`；`match_cut` 两侧写明形状、位置、大小、主色；对白没有跨接缝；`post.transitions` 列全 | 按 `../restaurant-story-planner/references/seams-and-transitions.md` 修改 |
| 多段声音 | 多段 `sound_mode = sfx_only`，BGM 与旁白后期统一加 | 改成 `BGM：无（后期统一配乐）` |

## 3. 输出 qa_report

`{pass, blockers[], warnings[], fixes[]}`（格式见 `../restaurant-video-director/references/contracts.md`）。有 blockers 就不放行。blockers = lint 的 ERROR + 人工清单里"菜品真实 / 不编造 / 文案合规 / 人像 / 模型与人脸"类不通过。warnings 不阻塞，但要展示给用户。

## 注意

- 极限词清单是常见风险提示，不是法律意见；上线前由商家或法务按平台规则复核。
- 改词只改 `references/banned-words.md`，脚本从那里读取。
- 模型上限只改 `model-profiles.json`，脚本从那里读取；档案里的数值来自第三方资料，先试拍再放量。
