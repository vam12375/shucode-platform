---
name: seedance-prompt-composer
description: 把分镜计划写成可直接投喂 Seedance 的竖屏提示词（时间轴 + @图片分工 + 连续性 + 声音 + 禁止），按所选模型分别处理：Seedance 2.5 单段 30 秒，Seedance 2.0 单段 15 秒、30/45/60 秒要拆成多段并写接缝出口与【承接】入口。含菜品保真锁定、菜品镜头库、4–6 秒菜品插入模板和多段拼接规则。在餐饮视频的分镜计划确定之后使用。
---

# Seedance 提示词编写（模型语言层）

输入：`shot_plan` + `assets` + 模型档案。输出：`prompt_pack`（见 `../restaurant-video-director/references/contracts.md`）。**新增或换视频模型只改本 skill 的 `references/models/` 和模型档案。**

## 步骤

1. **读模型档案和写法说明**：`../restaurant-video-director/references/model-profiles.json` 取 `single_pass_max`、`max_ranges`、`refs`、`ref_tag`、`face_reference`；再读 `references/models/<model>.md`。
2. **逐段写**：`shot_plan.segments` 里每个 segment 一条独立的提示词。
   - 把该段包含的幕的 beat 按顺序接起来，**时间重定基到 0 起**。
   - 时间段数不超过 `max_ranges`，每段 ≥2 秒；段内 beat 太多就合并最短的相邻 beat。
3. **编号参考图**：每段重新编号 `@图片1..N`，只放本段用到的图，**总数 ≤ `refs.image`**；每张图只有一个 job；菜品图的 job 行 = 用途 + 外观锁定句 + "不增减食材，不改变摆盘与器皿" + "不取背景和文字"。
4. **确定 `sound_mode`**：单段 `full`；多段 `sfx_only`。
5. **写接缝**（多段时）：
   - 上一段最后一个时间段的"结束画面" = 接缝出口。
   - 下一段加【承接】：`本段接上一段：画面从{入口}开始。` + 复述地点、人物、菜品、色调的锁定；第一个时间段从入口之后开始。
   - 同一段内的内接缝（如 2.5 的 A+B）：不写【承接】，把出口、入口写进相邻两个时间段。
   - 默认 `cut` 型接缝，不传首帧；`frame_chain` 才把上一段尾帧列进 `refs`（见 `models/seedance-2.0.md`）。
6. **菜品镜头**：从 `references/food-shot-library.md` 按 category / state 选"钩子 / 高潮"动作；每镜 ≤3 秒、一个轻动作；cold / iced 不加热气；raw 不做咬食。
7. **`fidelity_mode = insert`**：菜品特写用 `references/dish-insert-template.md` 单独成条；主片里该处写"切入菜品特写（后期插入）"的占位 beat。
8. **试拍**：`preview_first` 时，输出一条菜品插入模板的 5 秒提示词放进 `preview`。
9. **长度**：目标 ≤2000 字；超出按骨架里的删减顺序处理。
10. **填写 `prompt_pack`**：每个 segment 的 `seam_in / seam_out`；外接缝逐条列进 `post.transitions`（类型、剪辑、声音桥）。
11. **交给 food-video-qa**：对每段运行 `lint_prompt.py --model <model> --duration <该段时长>`（多段加 `--continuation` 或用 `.md` 多段文件），不通过就按 qa_report 改，别直接生成。

## 写作要点

- 动词具体、可拍：写"热气缓缓升起、筷子挑起一缕面条"，不写"好吃的面"。
- 一个 beat 一个主动作、一个主运镜；复合动作拆到相邻 beat。
- 人物只写身份锁定句 + 动作；POV 只写手和视线。
- 文字一律不让模型生成：招牌只作远景虚化，菜单、价格、店名全部留给后期。
- 【禁止】必带防翻车句（筷子、面条、汤汁、热气、食物凭空增加、器皿变形、手指）。
- 叮当等 IP 角色：外观锁定块原样引用 `../restaurant-story-planner/references/hosts.md`，不改写；**多段时每段都带设定图和姿势图**。
- 对白不跨外接缝；一句话在一段内说完。
- 冷菜、饮品、甜品的接缝不用热气类转场（`seams-and-transitions.md`）。

## 参考与示例

- 区块与格式：`references/prompt-skeleton.md`
- 模型写法：`references/models/seedance-2.5.md`、`references/models/seedance-2.0.md`
- 菜品镜头与防翻车：`references/food-shot-library.md`
- 菜品插入 / 试拍模板：`references/dish-insert-template.md`
- 多段与接缝写法：`references/long-video-splicing.md`
- 完整示例：
  - `examples/hotpot-15s.md`（15 秒，两个模型通用）
  - `examples/noodle-30s-seedance2.5.md`（30 秒，Seedance 2.5 单段）
  - `examples/noodle-30s-seedance2.0.md`（同一份输入，Seedance 2.0 拆成 2 段 + 1 个接缝）
  - `examples/bbq-60s-seedance2.5.md`（60 秒，Seedance 2.5 两段；文末有同一故事在 2.0 上的 4 段拆法）
