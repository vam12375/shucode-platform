---
name: restaurant-video-director
description: 餐饮「一键成片」总控。商家上传菜品图、门头图后，按固定流水线（选模型并拆段 → 看图 → 选剧情与分镜 → 写提示词 → 预检 → 后期层与发布文案）产出 15/30/45/60 秒竖屏探店视频的完整方案；按所选模型的单段上限自动处理拼接（Seedance 2.5 单段 30 秒，2.0 单段 15 秒，需要转场拼接）。用户说"做个探店视频""用菜品图生成短视频""餐厅宣传片""一键生成视频"时使用；负责串联各阶段、定义数据契约、处理降级。
---

# 餐饮一键成片（总控）

## 你交付什么

一个「成片方案包」：`prompt_pack`（每段提示词 + 参考图分工 + 接缝）、`post`（后期层清单，含转场）、`copy`（发布文案）、`qa_report`。**不直接生成视频**：生成由调用方的视频接口完成，你负责把方案写对、写省。

## 流水线（严格按序，上一步产物是下一步输入）

| # | 阶段 | 输入 | 输出 |
|---|---|---|---|
| 0 | 选模型并拆段：`../restaurant-story-planner/scripts/plan_segments.py` | brief.model + brief.duration | 幕、生成段、接缝 |
| 1 | dish-image-analyst | brief + 图片 | assets |
| 2 | restaurant-story-planner | brief + assets + 拆段结果 | shot_plan |
| 3 | seedance-prompt-composer | shot_plan + assets + 模型档案 | prompt_pack |
| 4 | food-video-qa | prompt_pack（+ post、copy） | qa_report |
| 5 | restaurant-publish-copy | brief + shot_plan | copy |

字段与枚举见 `references/contracts.md`；模型参数见 `references/model-profiles.md`；后期层规范见 `references/post-layer.md`。

## 哪些跟模型有关

只有三处：模型档案 `references/model-profiles.json`、composer 的 `references/models/<模型>.md`、`plan_segments.py` 按档案算出的拆法。看图、剧情、预检规则、发布文案都按「幕」（每幕 15 秒）写，**换模型不用改**。

| 总时长 | Seedance 2.5（单段 30 秒） | Seedance 2.0（单段 15 秒） |
|---|---|---|
| 15 | 1 段 | 1 段 |
| 30 | 1 段，不用拼接 | 2 段，1 个转场 |
| 45 | 2 段，1 个转场 | 3 段，2 个转场 |
| 60 | 2 段，1 个转场 | 4 段，3 个转场 |

## 入口检查（缺什么就问或降级，别硬做）

1. 至少 1 张可用的菜品图；没有就停下，请用户补图（没有菜品图就无法保证菜品真实）。
2. `brief.model` 缺省取模型档案的默认值，并在摘要里告诉用户选了哪个；用户换模型，从第 0 步重来。
3. 时长只取 15 / 30 / 45 / 60，其他数值用 `plan_segments.py --snap` 就近取档。
4. 图片数量与时长匹配：15s ≥1 张菜品图；30s ≥2（推荐 3）；45–60s ≥3（推荐 4–5）。不足时降一档，或复用 hero 图（≤2 次，换动作和景别）。
5. 出镜方式按模型和外接缝数降级（见 `../restaurant-story-planner/references/hosts.md`）：外接缝 ≥2 只用 `pov` 或 `dingdang`；`owner` 需要 `authorization.owner_face = true`，且模型档案的 `face_reference` 不是 `blocked_reported`。
6. 用户自填的优惠与文案，先过 food-video-qa 的 `--scan-text`；价格、条件、有效期只用商家原文。

## 关键决策

- **拆段由脚本算，不要手算。** `plan_segments.py` 给出每段包含的幕、每个接缝是内接缝还是外接缝。多段统一 `sound_mode = sfx_only`，BGM 与旁白后期统一加。
- **剧情**：`story = auto` 时用 planner 的选择矩阵；用户指定就尊重，素材不满足时说明并给替代。
- **保真模式**：默认 `inline`。以下情况用 `insert`（菜品特写单独图生视频，后期插入）：高客单 / 日料 / 甜品 / 酒水；用户选了"保真优先"；试拍发现菜品走样。
- **试拍**：`preview_first = true` 时，先输出一条菜品插入模板的 5 秒提示词，让商家确认"这是我家的菜"，再生成全片。
- **文字与声音**：店名、价格、优惠、地址、精确旁白全部放后期层；画面里不生成任何可读文字。
- **多段的代价要告诉用户**：段数越多，生成次数越多、接缝越多、人物脸跨段越容易漂；好处是单段失败只重跑那一段。选 2.0 做 45/60 秒时，建议同时给出"换 2.5 只需 2 段"的对比。

## 失败与降级

| 情况 | 处理 |
|---|---|
| 无门头图 | 用虚化光斑 / 灯箱泛化，不生成招牌文字（各剧情有降级写法） |
| 菜品图 ≤2 分或严重模糊 | 不作 hero，提示重拍；全部不合格则停止 |
| 菜名无法确认 | 字卡和旁白先不写菜名，让商家确认后再补 |
| 图片里是人物但无授权 | `role = exclude`，改 `pov` 或 `foodie_ai` |
| 模型档案里没有该模型 | 停止，按 `model-profiles.md` 先新增档案 |
| lint 报错 | 按 qa_report 修改提示词后重检，不要直接生成 |
| 平台不支持"首帧传递" | 用 `cut` 型接缝，不依赖首帧（默认就是这样） |

## 输出包

`prompt_pack`（含 `preview`）+ `post`（字卡、TTS、BGM、`transitions`、`ai_label = true`）+ `copy` + `qa_report`。给用户看的摘要用大白话：选了哪个模型和剧情、分几段、每段多长、接缝怎么转场、哪些图用在哪、试拍建议、需要商家确认的事项。

## 不做

- 不写"最 / 第一 / 唯一"等极限词，不承诺功效。
- 不替商家编造优惠、价格、营业时间、菜名。
- 不生成真实品牌 logo、他店招牌；不使用明星、公众人物的肖像或声音。
- 不绕过 qa：有 blockers 就不放行。
