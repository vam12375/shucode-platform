# 模型档案

套件里**跟模型有关的只有三处**：本目录的 `model-profiles.json`、composer 的 `references/models/<模型>.md`、`plan_segments.py` 按档案算出的拆法。看图、剧情、预检、发布文案都按「幕」写，换模型不用改。

## 怎么用

- 调用方在 `brief.model` 填档案的 key（默认 `seedance-2.5`）。
- 总控先用 `../../restaurant-story-planner/scripts/plan_segments.py` 算出「幕 → 生成段 → 接缝」，不要手算。
- composer 按档案的 `refs`、`max_ranges`、`ref_tag` 写提示词；`lint_prompt.py --model` 按同一份档案检查。

## 能力对照

来源是媒体报道、第三方指南和 API 服务商文档，**未对照官方文档**；不同入口（即梦网页、各 API 服务商）可能有差异，试拍确认。

| | Seedance 2.5 | Seedance 2.0 |
|---|---|---|
| 单段时长 | 4–30 秒 | 4–15 秒 |
| 参考素材 | 图 30 / 视频 10 / 音频 10 | 图 9 / 视频 3 / 音频 3（混合 ≤12 个） |
| 画面与声音 | 一起生成 | 一起生成 |
| 入口 | 未验证 | 全能参考（可 @ 引用）/ 首尾帧（只能 1–2 张图 + 文字） |
| 真人人脸参考 | 未验证 | 据报道会被人脸检测拒绝；风格化角色通过率高 |
| 每段时间段数（建议） | ≤6 | ≤5 |

## 拆法

`plan_segments.py` 的结果。幕长 15 秒；一段装得下几幕 = 单段上限 ÷ 15。

| 总时长 | Seedance 2.5（段数 / 外接缝） | Seedance 2.0（段数 / 外接缝） |
|---|---|---|
| 15 | 1 / 0 | 1 / 0 |
| 30 | 1 / 0 | 2 / 1 |
| 45 | 2 / 1 | 3 / 2 |
| 60 | 2 / 1 | 4 / 3 |

- **只有单段能到 30 秒的模型（2.5）才能不拼接地出 30 秒。** 单段 15 秒的模型（2.0）出 30/45/60 秒要拆成 2/3/4 段，每个外接缝都要做转场拼接（`../../restaurant-story-planner/references/seams-and-transitions.md`）。
- 段越多：生成次数越多，接缝越多，人物脸跨段漂移的风险越高；好处是单段失败只重跑那一段。
- 多段统一 `sound_mode = sfx_only`（BGM 与旁白后期统一加）；单段 `full`。

## 新增一个模型

1. 在 `model-profiles.json` 的 `models` 里新增条目，key 用小写加连字符（如 `your-model`），字段如下：

```json
"your-model": {
  "name": "显示名",
  "single_pass_max": 15,
  "single_pass_min": 4,
  "max_ranges": 5,
  "refs": {"image": 4, "video": 0, "audio": 0},
  "ref_tag": {"image": "@图片", "video": "@视频", "audio": "@音频"},
  "native_audio": true,
  "face_reference": "unverified",
  "unverified": ["prompt_char_limit"],
  "notes": ["数值来自该模型的官方文档或试拍结果"]
}
```

2. 在 `../../seedance-prompt-composer/references/models/` 新增 `your-model.md`，写这个模型的提示词写法与限制。
3. `single_pass_max` 必须 ≥15（剧情模板按 15 秒一幕写）；单段更短的模型要在幕内的时间段边界手动拆，套件不自动处理。
4. 跑 `python3 -I tests/test_kit.py`。

字段含义：`single_pass_max / min` 单段时长范围（秒）；`max_ranges` 单段时间轴建议的最多时间段数；`refs` 各类参考素材的数量上限（lint 检查图片）；`ref_tag` 提示词里的引用前缀；`face_reference` 真人人脸参考的状态（`blocked_reported` 据报道会被拒 / `unverified` 未验证 / `allowed`），出镜方式据此降级（`../../restaurant-story-planner/references/hosts.md`）。

## 未验证（上线前在你的入口逐项确认）

- 提示词字数上限（lint 的软上限 2000、硬上限 3000 字只是保守值）。
- `@图片N` 的写法在你的入口是否一致。
- 2.5 是否也分「全能参考 / 首尾帧」两个入口；2.0 的首尾帧入口不能同时带其他参考，所以含菜品或 IP 参考的段不要用它。
- 视频延长的规则（单次延长多久、能延长几次）；本套件默认不依赖它。
- 2.5 的真人人脸参考策略。
