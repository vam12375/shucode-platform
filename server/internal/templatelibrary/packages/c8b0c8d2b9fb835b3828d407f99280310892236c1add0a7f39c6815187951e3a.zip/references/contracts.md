# 数据契约

各阶段只通过下面 5 个 JSON 对象交接。字段名固定（英文），值用中文或枚举。允许多余字段；缺必填字段按错误处理。

## 枚举

| 名称 | 取值 |
|---|---|
| category 品类 | `hotpot` 火锅/麻辣烫 · `bbq` 烧烤/串串/烤肉 · `stirfry` 小炒/家常菜 · `noodle` 面/粉/粥 · `rice` 盖饭/煲仔饭/简餐 · `fried` 炸物 · `dessert` 甜品/烘焙 · `drink` 茶饮/咖啡/酒水 · `seafood` 海鲜/小龙虾 · `japanese` 日料 · `dimsum` 茶点/蒸点 · `hotplate` 铁板/烤鱼/干锅 · `cold` 凉菜/小吃 · `soup` 汤品/炖盅 |
| state 菜品状态 | `hot_steaming` 热气明显 · `hot` 热但热气不明显 · `sizzling` 滋滋作响 · `cold` 常温/凉 · `iced` 冰镇/带冰 · `raw` 生/待烹 · `dry` 干（酥脆/烘焙） |
| kind 图片类型 | `dish` · `storefront` · `interior` · `person` · `menu` · `logo` · `other` |
| role 图片角色 | `hero` 主菜 · `support` 配菜或第二第三道 · `establishing` 门头 · `atmosphere` 店内氛围 · `info_only` 只提取信息（菜单）· `exclude` 不使用 |
| goal | `traffic` 到店引流 · `opening` 新店开业 · `new_dish` 新品上市 · `festival` 节日活动 · `brand` 品牌故事 · `delivery` 外卖转化 |
| platform | `douyin` · `xiaohongshu` · `shipinhao` · `kuaishou` |
| style | `live_action` 实拍质感 · `cinematic` 电影感 · `cartoon_3d` 3D 动画 |
| host | `pov` · `foodie_ai` · `owner` · `dingdang` |
| story | `auto` 或 `pov-smell-detour` · `fire-to-table` · `duo-blind-rating` · `late-night-canteen` · `lunch-rescue` · `dish-quest` |
| model | 模型档案（`model-profiles.json`）的 key：`seedance-2.5`（默认）· `seedance-2.0`；其他模型按 `model-profiles.md` 新增 |
| fidelity_mode | `inline`（默认，菜品镜头在主片里生成）· `insert`（菜品特写单独图生视频，后期插入） |
| sound_mode | `full`（单段，含 BGM）· `sfx_only`（多段拼接，BGM 与旁白后期统一加） |
| duration | `15` · `30` · `45` · `60`（总时长；每段时长由模型档案决定） |
| act 幕 | `Z` 15 秒压缩 · `A` 开场 · `X1` `X2` 加餐 · `B` 收尾；每幕 15 秒 |
| seam type | `steam_wipe` · `whip_pan` · `object_cover` · `black_dip` · `match_cut` · `soft_flash` |
| seam kind | `inner` 同一次生成内部，模型完成 · `outer` 两次生成之间，剪辑转场 |
| seam method | `cut`（默认，不传首帧）· `frame_chain`（尾帧续接，见 seams-and-transitions.md） |

## 1. brief（调用方 → 总控）

```json
{
  "shop": {
    "name": "红姐牛油火锅",
    "category": "hotpot",
    "city": "成都",
    "area": "玉林路",
    "vibe": ["烟火气", "夜宵"],
    "price_per_person": 88,
    "signature_dishes": ["牛油锅底", "毛肚", "红糖糍粑"]
  },
  "goal": "traffic",
  "offer": "双人套餐 168 元，周一至周五晚市可用",
  "platform": "douyin",
  "model": "seedance-2.0",
  "duration": 30,
  "style": "live_action",
  "host": "pov",
  "story": "auto",
  "fidelity_mode": "inline",
  "preview_first": true,
  "images": [
    {"id": "img1", "uri": "uploads/pot.jpg", "hint": "牛油锅底"},
    {"id": "img2", "uri": "uploads/maodu.jpg", "hint": "毛肚"},
    {"id": "img3", "uri": "uploads/front.jpg", "hint": "门头夜景"}
  ],
  "must_include": ["毛肚下锅"],
  "must_avoid": [],
  "authorization": {"owner_face": false}
}
```

必填：`shop.name`、`shop.category`、`duration`、`images`（≥1 张菜品图）。`model` 省略时取模型档案的 `default`。`offer` 只能是商家原文，下游不得改写数字与条件。

## 2. assets（dish-image-analyst → planner）

```json
{
  "images": [
    {
      "id": "img1",
      "kind": "dish",
      "quality": {"score": 4, "issues": []},
      "dish": {
        "name": "牛油红汤锅底",
        "name_confidence": "high",
        "category": "hotpot",
        "state": "hot_steaming",
        "vessel": "不锈钢鸳鸯锅红汤一侧",
        "visible_ingredients": ["干辣椒", "花椒", "牛油"],
        "colors": ["深红", "油亮"]
      },
      "appearance_lock": "不锈钢锅里翻滚的牛油红汤，表面漂着干辣椒段和花椒，红油油亮，冒白色热气",
      "role": "hero",
      "risks": [],
      "crop_note": "横图转竖构图：取锅面中心，保留锅沿完整"
    },
    {
      "id": "img3",
      "kind": "storefront",
      "quality": {"score": 3, "issues": ["招牌文字清晰可读，视频里只作远景虚化"]},
      "dish": null,
      "appearance_lock": "夜晚街边火锅店门头，红色灯笼与暖黄灯箱，玻璃门透出热气",
      "role": "establishing",
      "risks": [],
      "crop_note": "竖构图取门头中上部"
    }
  ],
  "coverage": {"dish_count": 2, "has_storefront": true, "has_interior": false, "has_person": false},
  "menu_items": [],
  "warnings": ["缺少店内图：进店段用通用暖光桌面带过"]
}
```

## 3. shot_plan（planner → composer）

```json
{
  "story": "pov-smell-detour",
  "model": "seedance-2.0",
  "duration": 30,
  "style": "live_action",
  "host": "pov",
  "fidelity_mode": "inline",
  "acts": [
    {"act": "A", "t0": 0, "t1": 15},
    {"act": "B", "t0": 15, "t1": 30}
  ],
  "segments": [
    {"idx": 1, "acts": ["A"], "t0": 0, "t1": 15, "duration": 15, "sound_mode": "sfx_only"},
    {"idx": 2, "acts": ["B"], "t0": 15, "t1": 30, "duration": 15, "sound_mode": "sfx_only"}
  ],
  "seams": [
    {
      "k": 1, "after_act": "A", "before_act": "B", "at": 15,
      "kind": "outer", "between_segments": [1, 2], "type": "steam_wipe",
      "out": "桌上菜的热气越来越浓，涌向镜头，直到充满整个画面，近乎一片柔白",
      "in": "柔白的热气缓缓散开",
      "edit": "两段在白场处做 0.3 秒叠化；环境声交叉 0.4 秒"
    }
  ],
  "ref_map": [
    {"img": "img1", "job": "hero_dish"},
    {"img": "img2", "job": "support_dish"},
    {"img": "img3", "job": "storefront"}
  ],
  "beats": [
    {
      "n": 1, "act": "A", "segment": 1, "t0": 0, "t1": 3, "purpose": "hook",
      "image": "img1",
      "action": "红汤锅面微距，红油翻滚，热气升起化成金橙色香味丝带，从排风口钻出",
      "camera": "微距缓推，随丝带上升拉出",
      "sound": "红汤咕嘟声，丝带出现时一声清亮的叮",
      "end_frame": "丝带穿过窗口飘进傍晚的街"
    },
    {
      "n": 3, "act": "A", "segment": 1, "t0": 8, "t1": 15, "purpose": "arrive",
      "image": "img1",
      "action": "推门，门铃，服务员背影把红汤锅放到桌上，热气扑向镜头",
      "camera": "第一视角推门，落桌后定机位",
      "sound": "门铃，汤沸声",
      "end_frame": "热气充满整个镜头，近乎一片柔白（接缝 S1 出口）"
    },
    {
      "n": 4, "act": "B", "segment": 2, "t0": 15, "t1": 23, "purpose": "payoff",
      "image": "img2",
      "action": "柔白的热气散开；三连快切：红汤锅、毛肚下锅涮三下……最后一口：筷子送向镜头→黑场→睁眼",
      "camera": "微距 / 45°侧拍 / 第一视角",
      "sound": "滋啦下锅声，筷子碰锅沿",
      "end_frame": "睁眼，眼前是空了一半的桌面"
    }
  ],
  "voiceover": [
    {"t": 1, "who": "旁白", "text": "玉林路这条街，我鼻子一向很灵。", "in_model": false}
  ],
  "overlay": [
    {"t0": 26, "t1": 30, "type": "shop_card", "text": "红姐牛油火锅"},
    {"t0": 27, "t1": 30, "type": "offer", "text": "双人套餐 168 元，周一至周五晚市可用"}
  ],
  "notes": []
}
```

- `acts`、`segments`、`seams` 由 `restaurant-story-planner/scripts/plan_segments.py` 按 `model` 算出，不要手改。
- 把 `model` 换成 `seedance-2.5`：只有 1 个 segment（`acts: ["A", "B"]`，`sound_mode: "full"`），接缝 S1 的 `kind` 是 `inner`，没有 `edit`，也没有 `between_segments`。
- `seams[].type` 按剧情文件的主备规则取（k 奇数用主、偶数用备；冷菜不用 `steam_wipe`）；`out` / `in` 取剧情「接缝」表的画面描述。
- beat 的 `t0 / t1` 是整片绝对时间；composer 写提示词时按 segment 重定基到 0 起。真实输出包含该剧情该时长的全部 beat，这里只列三个示意。

## 4. prompt_pack（composer → qa）

```json
{
  "model": "seedance-2.0",
  "segments": [
    {
      "idx": 1,
      "acts": ["A"],
      "duration": 15,
      "sound_mode": "sfx_only",
      "prompt": "【规格】竖屏9:16，15秒，1080P。……（完整提示词）",
      "refs": [
        {"tag": "@图片1", "img": "img1", "job": "hero_dish"},
        {"tag": "@图片2", "img": "img3", "job": "storefront"}
      ],
      "seam_in": null,
      "seam_out": {"k": 1, "type": "steam_wipe", "method": "cut"},
      "chars": 1180
    },
    {
      "idx": 2,
      "acts": ["B"],
      "duration": 15,
      "sound_mode": "sfx_only",
      "prompt": "【规格】竖屏9:16，15秒，1080P。……【承接】本段接上一段：画面从一片柔白的热气开始……（完整提示词）",
      "refs": [
        {"tag": "@图片1", "img": "img1", "job": "hero_dish"},
        {"tag": "@图片2", "img": "img2", "job": "support_dish"},
        {"tag": "@图片3", "img": "img3", "job": "storefront"}
      ],
      "seam_in": {"k": 1, "type": "steam_wipe", "method": "cut", "from_segment": 1},
      "seam_out": null,
      "chars": 1260
    }
  ],
  "preview": {"duration": 5, "prompt": "【规格】竖屏9:16，5秒，1080P。……（菜品插入模板）", "refs": [{"tag": "@图片1", "img": "img1", "job": "hero_dish"}]},
  "post": {
    "overlay": [{"t0": 26, "t1": 30, "type": "shop_card", "text": "红姐牛油火锅"}],
    "tts": [{"t": 1, "text": "玉林路这条街，我鼻子一向很灵。"}],
    "bgm": "轻快尤克里里",
    "transitions": [
      {"k": 1, "after_segment": 1, "type": "steam_wipe", "edit": "两段在白场处做 0.3 秒叠化", "sound_bridge": "环境声交叉 0.4 秒；BGM 全片同一条"}
    ],
    "ai_label": true
  }
}
```

- 每个 segment 一条独立的提示词；`refs` 的 `tag` 数量不得超过模型档案的 `refs.image`。
- 第 2 段起 `seam_in` 必填。`method = cut`（默认）不传首帧；`frame_chain` 要把上一段尾帧列进 `refs`，由调用方负责截取。
- `post.transitions` 只列外接缝（两次生成之间）；内接缝由模型完成，不用列。
- `post.overlay` / `post.tts` 的时间是整片绝对时间。

## 5. qa_report（food-video-qa → 调用方）

```json
{
  "pass": false,
  "blockers": [
    {"code": "TIMELINE_GAP", "where": "segment 1", "msg": "第 2 个时间段起点 5 与上一段终点 4 不连续"}
  ],
  "warnings": [
    {"code": "CAUTION_WORD", "where": "offer", "msg": "“限时”需要写明截止时间"}
  ],
  "fixes": ["把第 2 个时间段起点改为 4，或把上一段延长到 5 秒"]
}
```

`pass=true` 的条件：`blockers` 为空。`warnings` 不阻塞，但要展示给用户。单段时长超过模型上限、参考图超过模型上限，都是 blocker。
