# 来源与方法限制

本包为 DineOps 独立编写的方法，不复制以下仓库的 Skill 正文、源码、脚本或执行器。来源固定于 2026-10-12 调研所读提交，便于回查；上游后续变化不自动成为本包行为。

| 固定来源 | 吸收的方法 | 本包的取舍 |
| --- | --- | --- |
| [Hypit 参考视频](https://github.com/hypit-ai/hypit/blob/85e01c76716498e6ec5b8bdfb6b374ca67f0195a/skills/hypit/references/creation/reference-video.md) | 整片与局部时间证据互校，记录元素出现、变化与消失 | 用观察蓝图和节拍关系；不接入 Hypit 运行器 |
| [Hypit 目标替换](https://github.com/hypit-ai/hypit/blob/85e01c76716498e6ec5b8bdfb6b374ca67f0195a/skills/hypit/references/creation/transformations.md) | 分离保留的制作机制与要替换的目标事实 | 人物、产品与场景来自用户真实资料，不默认行业 |
| [Hypit 语义时间](https://github.com/hypit-ai/hypit/blob/85e01c76716498e6ec5b8bdfb6b374ca67f0195a/skills/hypit/references/creation/script-and-time.md) | 把信息揭示与动作触发联系起来 | 真实原片参考仍固定源时间，不采用新台词重定全片长度 |
| [Hypit 成片审核](https://github.com/hypit-ai/hypit/blob/85e01c76716498e6ec5b8bdfb6b374ca67f0195a/skills/hypit/references/production/review.md) | 从实际输出定位问题并修正 | 区分已检查范围与未检查范围，不用抽帧宣称全片通过 |
| [Video Editor Agent 风格拆解](https://github.com/krusemediallc/video-editor-agent/blob/522856bc4b8036e4113c1f45752da8a9b938dfe2/.claude/skills/reel-style-clone/SKILL.md) | 切镜与镜内变化、字幕强调、补充画面的功能 | 把形容词变成具体关系；不固定作者经验比例或字体 |
| [Video Editor Agent 成片 QA](https://github.com/krusemediallc/video-editor-agent/blob/522856bc4b8036e4113c1f45752da8a9b938dfe2/.claude/skills/video-qa/SKILL.md) | 检查实际画面、声音和输出 | 只声明有证据的检查；不把所有静止、静音或硬切视作失败 |
| [Video Production Skills 复刻质检](https://github.com/Pluviobyte/video-production-skills/blob/e19f1f300eddbb4f73764e66849792ece94ff0b7/reference-video-replica-qc/SKILL.md) | 区分风格与逐帧目标，定位段落接缝，验收交付文件 | 换主体时比较动作、节奏与功能，不以像素差否定合理改编 |
| [AI 动效导演](https://github.com/Pluviobyte/video-production-skills/blob/e19f1f300eddbb4f73764e66849792ece94ff0b7/ai-motion-director/SKILL.md) | 变化应有目的、触发与交接 | 作为观察与编排方法；不宣称 DineOps 支持任意图层/动效 DSL |
| [Silent UGC Skill](https://github.com/jasonlee-breadcrumb/silent-ugc/blob/b9278da905dad5eea3930e99e6f710fe884779bd/skills/silent-ugc/SKILL.md) | 目标人物身份参考、姿态与手势、跨段连续性 | 分离身份与动作依据；不搬入供应商费用或自动切换路径 |

## 授权与证据边界

[Hypit LICENSE](https://github.com/hypit-ai/hypit/blob/85e01c76716498e6ec5b8bdfb6b374ca67f0195a/LICENSE) 对未经书面授权的多租户服务源码/衍生品使用有限制；本包不包含该实现。Video Editor Agent 与 Video Production Skills 在本次调研中未确认可复制授权，故仅记录方法来源并原创表达。[Silent UGC LICENSE](https://github.com/jasonlee-breadcrumb/silent-ugc/blob/b9278da905dad5eea3930e99e6f710fe884779bd/LICENSE) 为 MIT，也不据此将其中窄场景经验当成通用能力保证。

同一提交的 [Silent UGC README](https://github.com/jasonlee-breadcrumb/silent-ugc/blob/b9278da905dad5eea3930e99e6f710fe884779bd/README.md) 推荐只用图片、不用原片视频，并标示约 75 credits；Skill 正文却要求图片和视频参考，标示约 250 credits。该冲突未作为已经验证的技术结论采纳。DineOps 继续使用真实原片参考合同，实际动作与身份质量由成片验证，不靠静默换路径掩盖。

来源研究、包解析、路由和 payload 验证只能证明方法与调用接入。供应商生成到登录桌面合成的真实成片质量仍需实测；本包不提供已测成功率、收费数值或逐帧保真承诺。
