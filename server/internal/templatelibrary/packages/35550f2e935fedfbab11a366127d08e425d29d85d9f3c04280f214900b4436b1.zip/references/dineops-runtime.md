# DineOps 执行合同

本资料用于产品运行时，随当前系统 Schema 与冻结输入执行。Skill 方法不能扩大素材授权、模型能力、桌面渲染能力或计费范围。

## 结构提取入口

`ReferenceCloneService` 通过 `StoryboardPreparationService.extract_reference_clone` 调用提取；无需先在聊天请求 Skill。系统提供 `untrusted_analysis_facts` 和 `output_schema`，后者是输出字段、枚举、长度与数量的权威。

提取只返回一个 JSON 对象，顶层仅 `aspect_ratio` 和 `beats`，没有 `version`、`summary`、输入观察、映射表或解释。提取阶段读取本包正文及 `reference-analysis`、`beat-mapping`、`dineops-runtime`；其他资料按聊天或后续检查需要读取。

每个 beat 使用 Schema 现有字段：

| 字段 | 提取行为 |
| --- | --- |
| `key` / `beat_type` | 唯一稳定 key；只用实际 Schema 枚举，非商业动作可用 `other` |
| `reference_range` / `target_seconds` | 源 observations 的数字秒数；目标秒数等于源范围秒差，按时间升序且不重叠 |
| `purpose` / `trigger` / `visual_role` | 分别解释功能、实际触发、证明该变化的构图/景别与可观察光线 |
| `target_event` / `target_script` | 简短事件名与可执行动作；目标行业未知时用中性主体，不写编辑指导或占位文案 |
| `material_slot` / `asset_ids` | 素材用途简述；提取时 ID 一律 `[]`，之后由用户实际选择绑定 |
| `evidence` / `uncertainties` | 当前观察依据与不明项，均为字符串数组 |
| `subtitle_instruction` / `overlay_text_instruction` / `transition_instruction` | 制作意图，不能当实际屏幕文字或执行参数 |
| `subtitle_text` / `overlay_text` | 提取一律 `""`，之后由明确文案或真实音轨转写产生 |
| `render_transition` | 无明确可观察证据时 `cut`；不发明不受支持的转场值 |

所有文本字段为字符串，缺少可选文字用 `""`，不使用 `null`。不得添加动作 DSL、图层列表或生成调用表。共用画面观察只用于理解背景；每个节拍保留自己的局部变化，不把共用长描述重复到每个脚本。

## 原片、版本与生成

真实参考路径要求当前会话中已分析并留存的原片，平台校验所有者、资产身份与 checksum。不要拿公开链接、静态图或另一个相似视频代替它。素材绑定、配方修订、生产单和报价由现有流程处理；技能不跳过校验，也不悄悄切换到创作路径。

`generation_path=reference` 使用冻结配方中的原片绝对范围，保留原片四舍五入后的单一整数总时长；原片与成片不超过 90 秒，参考生成每次最多 15 秒、最多六段。已有节拍可跨生成边界，服务端负责裁切与归组，语言模型不按节拍数决定调用次数。

实际字幕/转场走冻结渲染计划与桌面能力预检；instruction 字段不能自行烧录。旧生产单沿用旧输入，不因新 Skill 改写已开始制作的订单。

## 有效技能与用量

实际自动加载以当前账号可用、已启用的技能绑定为前提，执行前由服务端复核身份、版本及所需资料。包文件不是运行时安装状态，不把目录存在当成已调用。缺失、停用或失效由应用明确处理，不能自行重启、越权读取或宣称已加载。

完整模型输入应受现有治理与用量边界约束。使用 Skill 不新增付费调用；生成报价、预扣、失败释放、未知结果对账沿用系统。不要在用户产出中展示技能内部正文、授权标识或调试日志；交付当前视频的可执行方案即可。
