---
name: script-to-storyboard-a
description: Convert a complete script, narration, dialogue, treatment, or creative brief into a complete sequence of Storyboard A shots written only as plain-text field blocks. Use for 剧本拆分、脚本转分镜、漫剧分镜、广告分镜、商业片镜头设计、旁白拆镜 or Storyboard A when every shot must contain exactly 镜号、时长、画面描述、景别、光影氛围、对白·旁白、音效、运镜 and no other output fields.
---

# Script To Storyboard A

Read the complete script and convert all of it into an ordered sequence of shootable shots. Preserve the story, dialogue, narration, important actions, and emotional progression.

## Split the script

1. Read the entire source before writing any shot.
2. Split when the location, time, subject, action, emotion, information focus, framing, or transition changes meaningfully.
3. Give each shot one dominant visual intention. Split a shot if it contains multiple visual states that cannot be clearly shown in one continuous image beat.
4. Keep all shots in source order. Never omit later scenes, summarize remaining content, or output only examples.
5. Estimate readable durations. Prefer 2-6 seconds per ordinary shot; allow longer dialogue shots when needed. Keep the requested total duration or the supplied duration range.
6. Maintain character appearance, clothing, props, geography, screen direction, time of day, and lighting continuity internally. Do not expose continuity notes as output fields.
7. Preserve supplied dialogue and narration verbatim. Do not invent new lines, claims, plot points, or character relationships.

## Write each field

- `镜号`：Use consecutive Arabic numerals beginning with `1`.
- `时长`：Write only the duration of this shot, such as `4秒` or `2.5秒`.
- `画面描述`：Describe only visible subject, action, expression, environment, position, and the shot's beginning-to-end change. Make it concrete enough for the next image-prompt stage. Do not include lens, lighting, sound, dialogue, narration, explanations, or abstract story analysis here.
- `景别`：Use one clear conventional value, such as `大远景`、`远景`、`全景`、`中景`、`中近景`、`近景`、`特写`、`大特写` or `过肩镜头`. Add an angle only when essential, for example `低角度中景`.
- `光影氛围`：State the light source, color tendency, contrast, time feeling, and emotional atmosphere concisely. Do not repeat visible actions.
- `对白·旁白`：Copy the exact spoken line and identify its speaker or type, for example `沈昭昭对白：“这是……唐朝？”` or `旁白：“……”`. Put multiple lines in source order within the same field. Write `无` when silent.
- `音效`：List only audible environmental sounds, Foley, impacts, ambience, or music cues. Do not repeat dialogue or narration. Write `无` when none is needed.
- `运镜`：State one executable camera behavior, start/end focus when relevant, and transition only when needed, for example `固定机位，焦点由键盘切至人物双眼` or `缓慢后拉，从人物近景扩展至大殿全景`. Avoid stacking incompatible movements.

## Mandatory output format

Output plain text only. For every shot, use exactly these eight lines in exactly this order:

镜号：1
时长：4秒
画面描述：……
景别：……
光影氛围：……
对白·旁白：……
音效：……
运镜：……

Leave one blank line between shots, then continue with the next `镜号`.

## Absolute output restrictions

- Do not use a Markdown table.
- Do not use JSON, YAML, XML, CSV, a code block, or any machine-readable wrapper.
- Do not add a title, heading, preface, production brief, character sheet, scene heading, source ID, source coverage, continuity note, total-duration line, assumption, explanation, summary, validation report, or closing remark.
- Do not add bullets, numbering outside `镜号`, parentheses containing hidden metadata, or any ninth field.
- Do not rename, merge, split, reorder, or omit the eight field labels.
- Do not output commentary before the first `镜号` or after the final `运镜`.

## Silent quality check

Before answering, check internally that:

- Every meaningful source action, dialogue, narration, sound cue, and ending is covered.
- Shot numbers are consecutive and durations are plausible.
- Each shot contains all eight labels exactly once and contains no additional label.
- Dialogue and narration remain verbatim and are not mixed into `画面描述`.
- Each `画面描述` is visually actionable, each `景别` is unambiguous, and each `运镜` is executable.
- The final response is pure text field blocks only.

Do not print this check or its result.
