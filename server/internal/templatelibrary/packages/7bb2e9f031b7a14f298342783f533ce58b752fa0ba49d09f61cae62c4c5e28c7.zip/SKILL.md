---
name: dish-image-analyst
description: 分析商家上传的餐饮图片（菜品、门头、店内、菜单、人物、logo）：逐张分类、判断能否用于 AI 视频、提取菜品要素，并为每道菜写一句「外观锁定句」，让生成的视频与实物一致。在为餐厅或美食制作视频、写视频提示词之前先用它看图。
---

# 菜品图分析（看图阶段）

输入：brief（含 `images` 列表和可选 `hint`）+ 图片本身。输出：`assets` JSON（字段与枚举见 `../restaurant-video-director/references/contracts.md`）。

## 步骤

1. **分类**：每张图归入 `kind`：dish / storefront / interior / person / menu / logo / other。一张图里有多种内容时，按画面主体归类。
2. **质量**：给 1–5 分并列出问题。长边 < 720px、严重模糊、过暗或过曝、有水印、带他店 logo 或招牌、手指遮挡主体，都写进 `issues`。≤2 分的图不进入 hero，并提示重拍。
3. **菜品要素**（`kind = dish`）：
   - `name`：先看 `hint`；与画面冲突时以画面为准并标 `name_confidence = low`；看不清就写"待确认：疑似……"。
   - `category`（14 选 1）、`state`（7 选 1）、`vessel`、`visible_ingredients`（只写看得见的）、`colors`。
   - 生肉、血水、酒类、明显的过敏原，写进 `risks`。
4. **外观锁定句**：按 `references/appearance-lock.md` 写 ≤45 字的一句话。门头、店内图也写，但只描述造型与光线，不写招牌上的字。
5. **角色**：最清晰、最有"钩子"的菜 = `hero`；其余 = `support`；门头 = `establishing`；店内 = `atmosphere`；菜单 = `info_only`（只 OCR 出 `menu_items`，不进视频）；logo 与人物按授权和用途标注。
6. **竖构图提示**：横图或方图要转 9:16 时，写 `crop_note`（取哪里、保留什么）。不拉伸。
7. **汇总**：`coverage`（各类数量）、`warnings`（缺门头 / 只有一张菜 / 太暗……）。

## 规则

- 只描述看得见的，不脑补食材、做法、产地、口味。
- 不确定的菜名别当事实写进旁白，让界面请商家确认。
- 人物图：只记录有无人脸，不识别身份；没有授权标记的人物图 `role = exclude`。
- 菜单与价目表只用于提取 `menu_items` 和价格，不当作视觉参考。
- 输出严格 JSON，不夹带解释文字。
