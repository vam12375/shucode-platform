#!/usr/bin/env python3
"""按模型档案把总时长拆成「幕 → 生成段 → 接缝」（仅标准库）。

幕是剧情的基本单位，每幕 15 秒，与模型无关；模型只决定一次能生成几幕：
  每段幕数 = 单段上限 // 15，幕按顺序从前往后装。
  Seedance 2.5（单段 30 秒）：30 秒 = 1 段，45 秒 = 2 段，60 秒 = 2 段。
  Seedance 2.0（单段 15 秒）：30 秒 = 2 段，45 秒 = 3 段，60 秒 = 4 段。
同一段里的幕边界是「内接缝」（模型自己完成过渡），段与段之间是「外接缝」（需要剪辑转场）。

用法：
  plan_segments.py --model seedance-2.0 --duration 45
  plan_segments.py --max-pass 30 --duration 60          不查档案，直接给单段上限
  plan_segments.py --model seedance-2.0 --duration 45 --json
  plan_segments.py --duration 40 --snap                 时长不是 15/30/45/60 时取最近档位
  plan_segments.py --matrix                             所有模型 × 时长的拆法（Markdown 表）
退出码：0 成功；2 参数或档案错误。
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

PROFILES_FILE = Path(__file__).resolve().parents[2] / "restaurant-video-director" / "references" / "model-profiles.json"
ACT_SECONDS = 15
ACTS_BY_DURATION = {15: ["Z"], 30: ["A", "B"], 45: ["A", "X1", "B"], 60: ["A", "X1", "X2", "B"]}
OUTER_SEAM_WARN = 2


def load_profiles(path: Path = PROFILES_FILE) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def snap_duration(duration: int) -> int:
    """取最近的合法档位（15/30/45/60）。"""
    return min(ACTS_BY_DURATION, key=lambda d: (abs(d - duration), d))


def plan_segments(duration: int, single_pass_max: int, model: str = "custom") -> dict:
    if duration not in ACTS_BY_DURATION:
        raise ValueError(f"时长只能是 {sorted(ACTS_BY_DURATION)}，收到 {duration}（可用 snap_duration 取最近档位）")
    if single_pass_max < ACT_SECONDS:
        raise ValueError(
            f"单段上限 {single_pass_max} 秒小于一幕（{ACT_SECONDS} 秒）：剧情模板按 15 秒一幕写，"
            "请在幕内的时间段边界手动拆，或换用单段 ≥15 秒的模型")
    acts = ACTS_BY_DURATION[duration]
    per_pass = single_pass_max // ACT_SECONDS
    groups = [acts[i:i + per_pass] for i in range(0, len(acts), per_pass)]
    start = {a: i * ACT_SECONDS for i, a in enumerate(acts)}
    sound_mode = "full" if len(groups) == 1 else "sfx_only"

    segments = []
    for idx, group in enumerate(groups, 1):
        t0 = start[group[0]]
        t1 = start[group[-1]] + ACT_SECONDS
        segments.append({"idx": idx, "acts": group, "t0": t0, "t1": t1,
                         "duration": t1 - t0, "sound_mode": sound_mode})

    seg_of = {a: s["idx"] for s in segments for a in s["acts"]}
    seams = []
    for k, after in enumerate(acts[:-1], 1):
        before = acts[k]
        outer = seg_of[after] != seg_of[before]
        seams.append({"k": k, "after_act": after, "before_act": before, "at": start[before],
                      "kind": "outer" if outer else "inner",
                      "between_segments": [seg_of[after], seg_of[before]] if outer else None})
    outer_n = sum(1 for s in seams if s["kind"] == "outer")

    warnings = []
    if outer_n >= OUTER_SEAM_WARN:
        warnings.append(
            f"外接缝 {outer_n} 个：人物脸跨段容易漂移，优先第一视角或风格化角色（见 hosts.md）；"
            "多段的好处是单段失败只需重跑该段")
    return {
        "model": model, "duration": duration, "single_pass_max": single_pass_max, "act_seconds": ACT_SECONDS,
        "acts": [{"act": a, "t0": start[a], "t1": start[a] + ACT_SECONDS} for a in acts],
        "segments": segments, "seams": seams,
        "outer_seams": outer_n, "generations": len(segments), "warnings": warnings,
    }


def render_text(p: dict) -> str:
    out = [f"模型 {p['model']}｜总时长 {p['duration']} 秒｜单段上限 {p['single_pass_max']} 秒｜幕长 {p['act_seconds']} 秒",
           "幕：" + "  ".join(f"{a['act']}({a['t0']}–{a['t1']})" for a in p["acts"]),
           f"生成段（共 {p['generations']} 次生成）："]
    for s in p["segments"]:
        out.append(f"  段{s['idx']}  {'+'.join(s['acts']):<6} {s['t0']}–{s['t1']} 秒  sound_mode={s['sound_mode']}")
    if p["seams"]:
        out.append("接缝：")
        for s in p["seams"]:
            if s["kind"] == "outer":
                where = "外接缝（需要剪辑转场）段{}→段{}".format(*s["between_segments"])
            else:
                where = "内接缝（模型内完成）"
            out.append(f"  S{s['k']}  {s['after_act']}→{s['before_act']}  在 {s['at']} 秒  {where}")
    else:
        out.append("接缝：无")
    out.extend(f"注意：{w}" for w in p["warnings"])
    return "\n".join(out)


def render_matrix(profiles: dict) -> str:
    keys = list(profiles["models"])
    lines = ["| 总时长 | " + " | ".join(f"{k}（段数 / 外接缝）" for k in keys) + " |",
             "|---|" + "---|" * len(keys)]
    for d in ACTS_BY_DURATION:
        cells = []
        for k in keys:
            p = plan_segments(d, profiles["models"][k]["single_pass_max"], k)
            cells.append(f"{p['generations']} / {p['outer_seams']}")
        lines.append(f"| {d} | " + " | ".join(cells) + " |")
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="按模型档案拆幕、拆段、定接缝", epilog=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--model", help="模型档案的 key；省略时用档案的 default")
    ap.add_argument("--max-pass", type=int, help="直接给单段上限（秒），不查档案")
    ap.add_argument("--duration", type=int, help="总时长：15 / 30 / 45 / 60")
    ap.add_argument("--snap", action="store_true", help="时长不是合法档位时取最近的档位")
    ap.add_argument("--profiles", type=Path, default=PROFILES_FILE, help="模型档案路径")
    ap.add_argument("--json", action="store_true", help="输出 JSON")
    ap.add_argument("--matrix", action="store_true", help="打印所有模型 × 时长的拆法")
    args = ap.parse_args(argv)

    try:
        if args.matrix:
            print(render_matrix(load_profiles(args.profiles)))
            return 0
        if args.duration is None:
            ap.error("需要 --duration（或使用 --matrix）")
        duration = snap_duration(args.duration) if args.snap else args.duration
        if args.max_pass is not None:
            model, single_pass_max = "custom", args.max_pass
        else:
            profiles = load_profiles(args.profiles)
            model = args.model or profiles["default"]
            if model not in profiles["models"]:
                raise ValueError(f"档案里没有模型 {model!r}，可选：{', '.join(profiles['models'])}")
            single_pass_max = profiles["models"][model]["single_pass_max"]
        plan = plan_segments(duration, single_pass_max, model)
    except (OSError, ValueError, KeyError) as exc:
        print(f"错误：{exc}", file=sys.stderr)
        return 2

    print(json.dumps(plan, ensure_ascii=False, indent=2) if args.json else render_text(plan))
    return 0


if __name__ == "__main__":
    sys.exit(main())
