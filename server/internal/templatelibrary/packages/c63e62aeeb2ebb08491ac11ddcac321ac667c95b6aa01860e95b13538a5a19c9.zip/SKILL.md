---
name: restaurant-story-planner
description: 为餐饮探店短视频选剧情模板并生成逐幕分镜计划：先按所选模型的单段上限把 15/30/45/60 秒拆成「幕」（每幕 15 秒）和生成段，设计段间转场接缝，再在 6 个探店剧情（闻香路过、一道菜的诞生、双人盲测、深夜食堂、午餐救星、吃货闯关）中选型，把菜品图和门头图绑定到具体镜头，产出旁白与后期字卡计划。在看图之后、写视频提示词之前使用。
---

# 剧情与分镜规划

输入：`brief` + `assets`。输出：`shot_plan` JSON（见 `../restaurant-video-director/references/contracts.md`）。**不写模型提示词**，那是 seedance-prompt-composer 的事。

## 步骤

1. **取拆法**：`python3 scripts/plan_segments.py --model <brief.model> --duration <brief.duration>`（加 `--json` 给程序用）。它按模型的单段上限算出幕、生成段、每个接缝是内接缝还是外接缝。**不要手算，也不要改结果。**
2. **选剧情**：`story = auto` 时按下面的矩阵选；用户指定就尊重，素材不满足时说明并给替代。
3. **选出镜方式**：读 `references/hosts.md`；默认 `pov`（第一视角，无正脸）。外接缝 ≥2 或模型 `face_reference = blocked_reported` 时按里面的规则降级。
4. **读剧情模板的幕表**：`references/stories/<id>.md`。15 秒用幕 Z；30 秒 = A + B；45 秒 = A + X + B；60 秒 = A + X + X + B。每个 X 幕绑定一道 support 菜，不够就降一档（`references/duration-profiles.md`）。
5. **设计接缝**：读 `references/seams-and-transitions.md` 和剧情的「接缝」表。每个接缝定类型（序号 k 奇数用主、偶数用备；冷菜、饮品、甜品不用 `steam_wipe`），写出口与入口；外接缝再写剪辑执行（叠化时长、声音桥）。
6. **绑定素材**：每个菜品镜头指定 image id 和 job；缺素材时按模板里的"降级"处理。
7. **写旁白与字卡计划**：旁白 ≤3 句（后期 TTS，用整片绝对时间）；字卡写 type / text / 时间；价格与优惠只用 brief 里的原文；对白不跨接缝。
8. **自检**：对照下面的"分镜硬规则"和"输出前检查"，不过就改。

## 剧情模板

| id | 名称 | 适合 | 出镜 | 文件 |
|---|---|---|---|---|
| `pov-smell-detour` | 闻香路过（第一视角探店） | 火锅 / 烧烤 / 小炒 / 面 / 饮品，引流 | pov | `references/stories/01-pov-smell-detour.md` |
| `fire-to-table` | 一道菜的诞生（一镜到底出菜） | 现炒 / 铁板 / 海鲜 / 日料，强调手艺 | 只拍手与背影 | `references/stories/02-fire-to-table.md` |
| `duo-blind-rating` | 双人盲测 PK | 聚餐类，要笑点 | foodie_ai ×2 / 叮当裁判 | `references/stories/03-duo-blind-rating.md` |
| `late-night-canteen` | 深夜食堂（治愈向） | 面 / 粥 / 小馆 / 夜宵，要情绪 | 背影 | `references/stories/04-late-night-canteen.md` |
| `lunch-rescue` | 打工人午餐救星 | 快餐 / 简餐，推套餐 | foodie_ai / pov | `references/stories/05-lunch-rescue.md` |
| `dish-quest` | 吃货闯关（30 秒起） | 火锅 / 烧烤，聚餐、开业 | 三双手 / 叮当向导 | `references/stories/06-dish-quest.md` |

## 选择矩阵

| 条件 | 首选 | 次选 |
|---|---|---|
| 火锅 / 烧烤 / 串串 / 川菜，目标引流 | pov-smell-detour | dish-quest |
| 火锅 / 烧烤，多人聚餐、想要笑点 | duo-blind-rating | dish-quest |
| 面 / 粉 / 粥 / 小馆 / 夜宵，要情绪 | late-night-canteen | pov-smell-detour |
| 快餐 / 简餐 / 盖饭 / 工作餐，推套餐 | lunch-rescue | pov-smell-detour |
| 炒菜 / 铁板 / 烤鱼 / 海鲜，强调现做与锅气 | fire-to-table | pov-smell-detour |
| 日料 / 高客单 / 创意菜 | fire-to-table（`insert` 模式） | late-night-canteen |
| 茶饮 / 咖啡 / 甜品 | pov-smell-detour（短） | fire-to-table |
| 新店开业 | pov-smell-detour 或 dish-quest（结尾带福利镜头） | — |
| 只有 1 张菜图 | 15 秒 pov-smell-detour | — |
| `host = dingdang` | dish-quest 或 duo-blind-rating（叮当当裁判） | 其余见 hosts.md |
| 外接缝 ≥2 且需要人物脸 | 换 `pov` 或叮当，或降一档时长 | — |

## 分镜硬规则

- 一个主角、一个地点（街 → 店算一条动线）、一个目标。
- 每幕 ≤15 秒；接缝只放在幕的边界；段尾"结束画面"是静态或半静态构图，不让动作在半空断开。
- 第一个 beat 是钩子：2–4 秒内出现最强视觉（热气 / 拉丝 / 火焰 / 淋汁）。
- 最后一个 beat 是收尾：≥3 秒，留给店名与优惠字卡的干净画面。
- 菜品镜头合计 ≥40% 时长；每个菜品镜头 ≤3 秒；同一道菜一次只做一个轻动作。
- 每个 beat 只写一个主动作 + 一个主运镜，并写"结束画面"。
- 出镜人物 ≤2；对白（模型内）≤3 句、每句 ≤8 字、不跨接缝；POV 或无人出镜时无对白，旁白放后期。
- 画面里不出现价格、优惠、店名文字。
- 不在画面里编造菜单上没有的菜。

## 输出前检查

- `ref_map` 里每张图有且只有一个 job；每个 beat 的 `image` 都在 `ref_map` 里。
- `acts`、`segments`、`seams` 与 `plan_segments.py` 的结果一致。
- 时间连续：t0 = 0，每个 beat 的起点 = 上一个的终点，终点 = 总时长；每个幕边界上都有 beat 边界。
- 每个外接缝：有类型、出口、入口、剪辑执行；冷菜没有用 `steam_wipe`；同一类型没有连续出现 3 次。
- 多段时：每段末 beat 的 `end_frame` = 该接缝的出口，下一段首 beat 从该接缝的入口开始。
